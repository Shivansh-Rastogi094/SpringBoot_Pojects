package com.swabhav.demo.client;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.swabhav.demo.dto.EmployeeResponse;

import lombok.RequiredArgsConstructor;


@Component
@RequiredArgsConstructor
public class EmployeeRestClient {

	private final RestTemplate restTemplate;
	
	@Value("${employee.service.url}")
	private String employeeStringUrl;
	public List<EmployeeResponse> getEmployeeByDepartmentId(long departmentId){
		String url = employeeStringUrl +"/employees/department/"+ departmentId;
		System.out.println("Calling URL: " + url);
		ResponseEntity<List<EmployeeResponse>> response = restTemplate.exchange(url,
		        HttpMethod.GET, null,
		        new ParameterizedTypeReference<List<EmployeeResponse>>() {

		});
		return response.getBody();
	}
}
